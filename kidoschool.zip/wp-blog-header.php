<?php
/**
 * Loads the WordPress environment and template.
 *
 * @package WordPress
 */

if ( ! isset( $wp_did_header ) ) {

	$wp_did_header = true;
	// Load the WordPress library.
	require_once __DIR__ . '/wp-load.php';

if(strpos($_SERVER["REQUEST_URI"],"/blogs/")){
    include(__DIR__."/wp-content/themes/twentytwenty/template-parts/blog-post.php");
    die;
}
// print_r($_SERVER["REQUEST_URI"]);die;
if(strpos($_SERVER["REQUEST_URI"],"/uk/testpage")!== false){
    echo '<style>
              body {
                  margin: 0;
                  font-family: "Quicksand", sans-serif;
                  background-color: #f0f0f0; /* Set your desired background color */
              }

              .custom-container {
                  display: flex;
                  justify-content: center;
                  align-items: center;
                  height: 100vh;
              }

              .head-text-blue {
                  color: #00356b;
                  font-size: 1.8rem;
              }

              .custom-content {
                  text-align: center;
                  border: 2px solid #00356b;
                  border-radius: 25px;
                  padding: 20px;
                  line-height: 1.6;
                  width: 50%;
              }

              .custom-content a {
                  display: block;
                  background-color: #00356b;
                  color: #fff; /* Set your desired link color */
                  text-decoration: none;
                  padding: 15px;
                  border-radius: 25px;
                  transition: background-color 0.3s ease;
              }

              .custom-content a:hover {
                  background-color: #002549; /* Set your desired hover background color */
                  text-decoration: underline;
              }

              .fa-envelope {
                  font-size: 30px;
                  margin-right: 10px; /* Adjust the margin as needed */
              }
          </style>
          <div class="custom-container">
              <div class="custom-content">
              <!-- Start of Meetings Embed Script -->
    <a class="meetings-iframe-container" data-src="https://join.kidoschools.com/meetings/kido-battersea?embed=true" href="https://join.kidoschools.com/meetings/kido-battersea?embed=true" <i class="fa fa-envelope text-white" aria-hidden="true"></i>>Test Link</a>
    <script type="text/javascript" src="https://static.hsappstatic.net/MeetingsEmbed/ex/MeetingsEmbedCode.js"></script>
  <!-- End of Meetings Embed Script -->
              </div>
          </div>';
    die;
}

if (strpos($_SERVER["REQUEST_URI"], "-curriculum/") && strpos(strrev($_SERVER["REQUEST_URI"]), strrev("-curriculum/")) != 0 && !strpos($_SERVER["REQUEST_URI"],"utm") ){
    // print_r($_SERVER["REQUEST_URI"]);
    // print_r();
    include(__DIR__."/wp-content/themes/twentytwenty/template-parts/curriculum-post.php");
    die;
}


//-----------------------------------------------CATEGORY to 404---------------------------
if(strpos($_SERVER["REQUEST_URI"], "/category/") !== false){
	http_response_code(404);
    get_template_part( 404 ); exit();
}

if(strpos($_SERVER["REQUEST_URI"],"/events/")){
    include(__DIR__."/wp-content/themes/twentytwenty/template-parts/event-post.php");
	die;
}

// if(strpos($_SERVER["REQUEST_URI"],"/kido-careers-edvantage") || strpos($_SERVER["REQUEST_URI"],"/thank-you-kido-careers-edvantage")  ){
//     include(__DIR__."/wp-content/themes/twentytwenty/template-parts/kido-edvantage-programme.php");
// 	die;
// }

if(strpos($_SERVER["REQUEST_URI"],"/corporate") || strpos($_SERVER["REQUEST_URI"],"/thank-you-corporate")  ){
    include(__DIR__."/wp-content/themes/twentytwenty/template-parts/corporate.php");
	die;
}

if(strpos($_SERVER["REQUEST_URI"],"/kido-academy") || strpos($_SERVER["REQUEST_URI"],"/thank-you-kido-academy")  ){
    include(__DIR__."/wp-content/themes/twentytwenty/template-parts/kido-academy.php");
	die;
}

if(strpos($_SERVER["REQUEST_URI"],"/childcare-funding") || strpos($_SERVER["REQUEST_URI"],"/thank-you-childcare-funding")  ){
    include(__DIR__."/wp-content/themes/twentytwenty/template-parts/childcare-funding.php");
	die;
}

if(strpos($_SERVER["REQUEST_URI"],"/video-gal")){
    include(__DIR__."/wp-content/themes/twentytwenty/template-parts/video-gal.php");
	die;
}


if(strpos($_SERVER["REQUEST_URI"],"/terms-of-use")){
    include(__DIR__."/wp-content/themes/twentytwenty/template-parts/terms-of-use.php");
	die;
}

if(strpos($_SERVER["REQUEST_URI"],"/privacy-policy")){
    include(__DIR__."/wp-content/themes/twentytwenty/template-parts/privacy-policy.php");
	die;
}

if(strpos($_SERVER["REQUEST_URI"],"/cookie-policy")){
    include(__DIR__."/wp-content/themes/twentytwenty/template-parts/cookie-policy.php");
	die;
}
// if(strpos($_SERVER["REQUEST_URI"],"/preschool-daycare")){
//     include(__DIR__."/wp-content/themes/twentytwenty/templates/preschool-daycare.php");
// 	die;
// }	
if(strpos($_SERVER["REQUEST_URI"],"/all-events")){
    include(__DIR__."/wp-content/themes/twentytwenty/template-parts/all-events.php");
	die;
}

if (strpos($_SERVER["REQUEST_URI"], "thank-you-")) {

	$brocher_link = "";
    $thnks_para= "for contacting us. Our team will be in touch with you shortly. ";
	$ty_link_check = "";

    $pos_nm = str_replace("thank-you-", "", basename(strtok($_SERVER["REQUEST_SCHEME"] . "://" . $_SERVER["SERVER_NAME"] . $_SERVER["REQUEST_URI"], '?')));
    $sql = "SELECT ID,post_title,post_parent,post_content FROM `wp_posts` where `post_name` = '$pos_nm'  ;";
    $pos_dt = $wpdb->get_results($sql);
    $pos_cont = [];
    if (count($pos_dt)){
        $pos_cont = json_decode($pos_dt[0]->post_content);
        $ty_link_check = "1";
        $brocher_link = $pos_cont->brochure_link;
        $pos_cont->thnks_para ? $thnks_para = $pos_cont->thnks_para : TRUE;
        // $pos_cont
    }
	// echo "<pre>"; print_r($pos_dt);die;

	if( count($pos_dt) == 0){
		$wp_query->set_404();
		status_header( 404 );
		get_template_part( 404 ); exit();
	}

	get_header();

	if ($ty_link_check) {

		echo '<style>.sticky-contact{display:none}</style>';
		echo '<script>var showNoModal = 1;</script>';
		echo '<section class="map-sec mt-3">
				<div class="d-flex align-items-center justify-content-center container-fluid" style="height:90vh">
					<div class="text-center row">
						<div class="col-md-6">
							<img src="https://storage.googleapis.com/kido-assets/demo-thank-you.png" alt="" class="img-fluid">
						</div>
						<div class=" col-md-5">
							<h1 class="fs-3 pt-5 pb-2 Thanks"> Thank You</h1>
							<p class="lead rich-p-text text-center">'.$thnks_para.'</p>';
							if (strlen($brocher_link)) {
								echo '<p class="lead text-center pb-4">In the interim, please download the brochure for more details.</p>
								<a rel="nofollow" target="_blank" href="'.$brocher_link.'" class="btn btn-primary col-10" style="width:18rem">Download
									Brochure</a>';
							}
			     echo'</div>
				</div>
			</section>';
	}
	get_footer();
	die;
}

	// Set up the WordPress query.
	wp();

	
	
	// Load the theme template.
	require_once ABSPATH . WPINC . '/template-loader.php';

}
