<?php
/**
 * Front to the WordPress application. This file doesn't do anything, but loads
 * wp-blog-header.php which does and tells WordPress to load the theme.
 *
 * @package WordPress
 */

/**
 * Tells WordPress to load the WordPress theme and output it.
 * 
 * @var bool
 */




//-----------------------------------------------ROBOTS.TXT---------------------------


if($_SERVER["REQUEST_URI"] == "/robots.txt"){
    // print_r($_SERVER["REQUEST_URI"]);
    echo "User-agent : * <br>
    Allow:  <br> 
    User-agent: CCBot<br> 
    Disallow: /author/ <br>
    Disallow: /category/ <br>
    Disallow: / <br>";
    echo "sitemap: https://kidoschools.com/global-sitemap.xml";
    die;
}

//<--------------------------------------UK-sitemap----------------------------------->

if(strpos($_SERVER["REQUEST_URI"], "/uk/") !== false){
    if(strpos($_SERVER["REQUEST_URI"], "/robots.txt") !== false){
        echo "User-agent : * <br>
        Allow:  <br> 
        User-agent: CCBot<br> 
        Disallow: /author/ <br>
        Disallow: /category/ <br>";
        echo "sitemap: 'https://kidoschools.com/uk-sitemap.xml','https://kidoschools.com/uk-blog-sitemap.xml'";
        die;
    }
    if(strpos($_SERVER["REQUEST_URI"], "blog-sitemap.xml") !== false){
        header("Content-Type: application/xml");
        readfile("https://kidoschools.com/uk-blog-sitemap.xml");
        die;
    }elseif (strpos($_SERVER["REQUEST_URI"], "sitemap.xml") !== false){
        header("Content-Type: application/xml");
        readfile("https://kidoschools.com/uk-sitemap.xml");
        die;
    }
}

//<--------------------------------------IN-sitemap----------------------------------->

if(strpos($_SERVER["REQUEST_URI"], "/in/") !== false){
    if(strpos($_SERVER["REQUEST_URI"], "/robots.txt") !== false){
        echo "User-agent : * <br>
        Allow:  <br> 
        User-agent: CCBot<br> 
        Disallow: /author/ <br>
        Disallow: /category/ <br>";
        echo "sitemap: 'https://kidoschools.com/in/sitemap.xml','https://kidoschools.com/in/blog-sitemap.xml'";
        die;
    } 
    if(strpos($_SERVER["REQUEST_URI"], "blog-sitemap.xml") !== false){
        header("Content-Type: application/xml");
        readfile("https://kidoschools.com/in-blog-sitemap.xml");
        die;
    }elseif(strpos($_SERVER["REQUEST_URI"], "sitemap.xml") !== false){
        header("Content-Type: application/xml");
        readfile("https://kidoschools.com/in-sitemap.xml");
        die;
    }
}


//<--------------------------------------US-sitemap----------------------------------->

if(strpos($_SERVER["REQUEST_URI"], "/us/") !== false){
    if(strpos($_SERVER["REQUEST_URI"], "/robots.txt") !== false){
        echo "User-agent : * <br>
        Allow:  <br> 
        User-agent: CCBot<br> 
        Disallow: /author/ <br>
        Disallow: /category/ <br>";
        echo "sitemap: 'https://kidoschools.com/us-sitemap.xml','https://kidoschools.com/us-blog-sitemap.xml";
        die;
    } 
    if(strpos($_SERVER["REQUEST_URI"], "blog-sitemap.xml") !== false){
        header("Content-Type: application/xml");
        readfile("https://kidoschools.com/us-blog-sitemap.xml");
        die;
    }elseif(strpos($_SERVER["REQUEST_URI"], "sitemap.xml") !== false){
        header("Content-Type: application/xml");
        readfile("https://kidoschools.com/us-sitemap.xml");
        die;
    }
}
// handle other requests here

define( 'WP_USE_THEMES', true );

/** Loads the WordPress Environment and Template */
require __DIR__ . '/wp-blog-header.php';

?>




