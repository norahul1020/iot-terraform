<?php

ini_set('display_errors', '1');
ini_set('display_startup_errors', '1');
error_reporting(E_ALL);
// echo "<pre>";print_r($_SERVER);die;
require_once __DIR__ . '/../wp-admin/mail_files/Exception.php';
require_once __DIR__ . '/../wp-admin/mail_files/PHPMailer.php';
require_once __DIR__ . '/../wp-admin/mail_files/SMTP.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

function isJson($string)
{
  json_decode($string);
  return (json_last_error() == JSON_ERROR_NONE);
}

// passing true in constructor enables exceptions in PHPMailer
function php_mailer($data)
{
  $mail = new PHPMailer(true);
  try {
    // Server settings
    $mail->SMTPDebug = SMTP::DEBUG_SERVER; // for detailed debug output
    $mail->isSMTP();
    $mail->Host = 'smtp.gmail.com';
    $mail->SMTPAuth = true;
    $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
    $mail->Port = 587;

    $sender = "kidoindia@kidoschools.com";
    $passwd = "ydbeozqojyblyukp";

    // $to = "ziauddin.sayyed@kido.school";
    // $cc = "fauzan.falke@kido.school";
    // $rece_nm = "Receiver Name";
    $mail->Username = $sender; // YOUR gmail email
    $mail->Password = $passwd; // YOUR gmail password

    $mail->setFrom($sender, 'Kido Team');
    $mail->addAddress($data['to'], $data['receiver_name']);
    foreach ($data['cc'] as $k => $v) {
      // isset($data['cc']) ? ) : FALSE;
      $mail->addCC($v);
    }
    $mail->addReplyTo($sender, 'Kido Team');

    $mail->IsHTML(true);
    $mail->Subject = $data['subject'];
    $mail->Body = $data['message'];
    // $mail->AltBody = 'Plain text message body for non-HTML email client. Gmail SMTP email body.';

    $mail->send();
    echo "Email message sent.";
  } catch (Exception $e) {
    echo "Error in sending email. Mailer Error: {$mail->ErrorInfo}";
  }
}

if ($_SERVER['REQUEST_METHOD'] == 'GET') {
  header("HTTP/1.0 404 Not Found");
  $preAddr = $_SERVER["REQUEST_SCHEME"] . "://" . $_SERVER['HTTP_HOST'];
  if (substr($_SERVER['REMOTE_ADDR'], 0, 4) == '127.' || $_SERVER['REMOTE_ADDR'] == '::1') {
    $preAddr .= "/kidoschools";
  }
  header("Location: $preAddr");
} else {

  if (isset($_POST["api"])) {
    if ($_POST["api"] == "job_apply") {
      $curl = curl_init();
      curl_setopt_array(
        $curl,
        array(
          CURLOPT_URL => 'https://kido-events-default-rtdb.firebaseio.com/jobapply.json',
          CURLOPT_RETURNTRANSFER => true,
          CURLOPT_ENCODING => '',
          CURLOPT_MAXREDIRS => 10,
          CURLOPT_TIMEOUT => 0,
          CURLOPT_FOLLOWLOCATION => true,
          CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
          CURLOPT_CUSTOMREQUEST => 'POST',
          CURLOPT_POSTFIELDS => json_encode($_POST),
          CURLOPT_HTTPHEADER => array(
            'Content-Type: application/json'
          ),
        )
      );

      $response = curl_exec($curl);
      curl_close($curl);

      $msg_htm = 'Name : <b>' . $_POST['name'] . '</b><br>'
        . 'Email : <b>' . $_POST['email'] . '</b><br>'
        . 'Phone : <b>' . $_POST['phone'] . '</b><br>'
        . 'Job Name : <b>' . $_POST['sel_job_name'] . '</b><br>'
        . 'Job Location : <b>' . $_POST['sel_job_locn'] . '</b><br>'
        . '<a href="' . $_POST['resume'] . '" target="_blank">View CV</a>';

      $cc_ls = [
        "hr@kido.school",
        "aquib.nakhwa@kido.school",
        "ziauddin.sayyed@kido.school"
      ];
      $dets = [
        "to" => "careers.india@kidoschools.com",
        // "to" => "akmal@amelio.in",,
        "cc" => $cc_ls,
        "receiver_name" => "Kido HR Team.",
        "subject" => "Kido New Job Application.",
        "message" => $msg_htm
      ];
      php_mailer($dets);

      echo $response;
    }


    if ($_POST["api"] == "jobapply_test") {
      $curl = curl_init();
      curl_setopt_array(
        $curl,
        array(
          CURLOPT_URL => 'https://kido-events-default-rtdb.firebaseio.com/jobapply_test.json',
          CURLOPT_RETURNTRANSFER => true,
          CURLOPT_ENCODING => '',
          CURLOPT_MAXREDIRS => 10,
          CURLOPT_TIMEOUT => 0,
          CURLOPT_FOLLOWLOCATION => true,
          CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
          CURLOPT_CUSTOMREQUEST => 'POST',
          CURLOPT_POSTFIELDS => json_encode($_POST),
          CURLOPT_HTTPHEADER => array(
            'Content-Type: application/json'
          ),
        )
      );

      $response = curl_exec($curl);
      curl_close($curl);

      $msg_htm = 'Name : <b>' . $_POST['full_name'] . '</b><br>'
        . 'Email : <b>' . $_POST['email_address'] . '</b><br>'
        . 'Phone : <b>' . $_POST['phone_number'] . '</b><br>'
        . 'Job Name : <b>' . $_POST['date_birth'] . '</b><br>'
        . 'Education : <b>' . $_POST['education'] . '</b><br>'
        . 'Location : <b>' . $_POST['location'] . '</b><br>'
        . 'Hear About Us : <b>' . $_POST['hear_about'] . '</b><br>';

      $cc_ls = [
        // "aquib.nakhwa@kido.school",
        "ziauddin.sayyed@kido.school",
        // "akmal@amelio.in"
      ];
      $dets = [
        "to" => "aquib.nakhwa@kido.school",
        // "to" => "kidoacademy@kidoschools.in",
        "cc" => $cc_ls,
        "receiver_name" => "Kido Academy Team.",
        "subject" => "Kido Academy Application.",
        "message" => $msg_htm
      ];
      php_mailer($dets);

      echo $response;
    }

    if ($_POST["api"] == "get_body_content") {
      $htmlContent = file_get_contents($_POST["trgtUrl"]);
      preg_match('/<main[^>]*>(.*?)<\/main>/is', $htmlContent, $matches);
      // echo $matches[0];
      $out = str_replace('src="/hs/', 'src="https://join.kidoschools.com/hs/', $matches[0]);
      // $out = str_replace('/hs/scriptloader/',"https://join.kidoschools.com/hs/hsstatic/" ,$matches[0]);
      print_r($out);
      die;
    }

    if ($_POST["api"] == "corporate_apply") {
      $curl = curl_init();
      curl_setopt_array(
        $curl,
        array(
          CURLOPT_URL => 'https://kido-events-default-rtdb.firebaseio.com/corporate.json',
          CURLOPT_RETURNTRANSFER => true,
          CURLOPT_ENCODING => '',
          CURLOPT_MAXREDIRS => 10,
          CURLOPT_TIMEOUT => 0,
          CURLOPT_FOLLOWLOCATION => true,
          CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
          CURLOPT_CUSTOMREQUEST => 'POST',
          CURLOPT_POSTFIELDS => json_encode($_POST),
          CURLOPT_HTTPHEADER => array(
            'Content-Type: application/json'
          ),
        )
      );

      $response = curl_exec($curl);
      // print_r($response);die;
      curl_close($curl);

      $msg_html = 'Name : <b>' . $_POST['corp_fullname'] . '</b><br>'
        . 'Email : <b>' . $_POST['corp_email'] . '</b><br>'
        . 'Phone : <b>' . $_POST['corp_phone'] . '</b><br>'
        . 'City : <b>' . $_POST['corp_city'] . '</b><br>'
        . 'Company Name : <b>' . $_POST['corp_company'] . '</b><br>'
        . 'Designation : <b>' . $_POST['corp_designation'] . '</b><br>'
        . 'Message : <b>' . $_POST['corp_desc_1'] . '</b><br>';

      $cc_list = ["aquib.nakhwa@kido.school"];
      $details = [
        "to" => "indiacorp@kidoschools.in",
        // "cc" => $cc_list,
        "receiver_name" => "Kido Corporate Solutions Team.",
        "subject" => "Kido Corporate Solutions Application.",
        "message" => $msg_html
      ];

      // Assuming php_mailer is a function to handle sending emails
      php_mailer($details);

      echo $response;
    }

    if ($_POST["api"] == "amelio_lead_zoho") {


      $curl = curl_init();

      curl_setopt_array($curl, array(
        CURLOPT_URL => 'https://accounts.zoho.in/oauth/v2/token?refresh_token=1000.3d03f2b587f15339318666f6776be8cd.8e02adae3f1a1571152361ad1ac65eb3&client_id=1000.H8ZQSAKQE10IFLCNH2AXKJIU71UL6E&client_secret=de48173a6c420d7d2c2fa29bd474bb8b8c76071134&grant_type=refresh_token',
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => '',
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 0,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => 'POST',
      )
      );

      $response = curl_exec($curl);
      curl_close($curl);
      // echo $response;
      $accTokn = json_decode($response, true)["access_token"];

      // print_r(json_decode($response,true)["access_token"]);die;

      $curl = curl_init();

      curl_setopt_array($curl, array(
        CURLOPT_URL => 'https://www.zohoapis.in/crm/v2/Leads',
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => '',
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 0,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => 'POST',
        CURLOPT_POSTFIELDS => '{
          "data": [
                {
                  "Lead_Source": "' . $_POST['Lead_Source'] . '",
                  "Company": "",
                  "Last_Name": "' . $_POST['Lead_Name'] . '",
                  "Email": "' . (isset($_POST['Email']) ? $_POST['Email'] : "") . '",
                  "Lead_Name": "' . $_POST['Lead_Name'] . '",
                  "Centres_Available_in_Chennai_Bangalore_Hyderabad":"' . $_POST['Centre'] . '",
                  "Child_s_Name":"' . $_POST['Child_s_Name'] . '",
                  "st_Child_Age":"' . $_POST['st_Child_Age'] . '",
                  "Phone": "' . $_POST['Phone'] . '",
                  "City":"' . $_POST['City'] . '",
                  "Medium":["' . (isset($_POST['Medium']) ? $_POST['Medium'] : $_POST['Program_Interested_In']) . '"],
                  "Program_Interested_In": ["' . $_POST['Program_Interested_In'] . '"],
                  "Enquiry_Date1": "' . date('Y-m-d') . '",
                }
              ]
            }',
        CURLOPT_HTTPHEADER => array(
          'Content-Type: application/json',
          'Authorization: Zoho-oauthtoken ' . $accTokn
        ),
      )
      );

      $response = curl_exec($curl);

      curl_close($curl);
      // echo json_encode(["msg"=>"Lead saved"]);
      print_r(json_encode(["msg" => "Lead saved"]));
      die;

    }

  } else {

    $jsonData = file_get_contents('php://input');

    if (isJson($jsonData) && isset($_SERVER['QUERY_STRING'])) {
      // parse_str($jsonData, $parsedDataArray);
      // print_r($parsedDataArray);
      parse_str($_SERVER['QUERY_STRING'], $inpReq);
      // print_r( $array );
      // die;
      if ($inpReq["query"] == "send_amelio_query") {
        $data = json_decode($jsonData, true);
        $msg_html = 'Hi Team, <br> Inquiry received from kido website.<br>'
          . 'Parent Name : <b>' . $data['parent_name'] . '</b><br>'
          . 'Parent Email : <b>' . $data['parent_email'] . '</b><br>'
          . 'Phone : <b>' . $data['parent_first_contact'] . '</b><br>'
          . 'Center : <b>' . $data['desc'] . '</b><br>'
          . 'Child Name : <b>' . $data['child_name'] . '</b><br>'
          . 'Child DOB : <b>' . $data['child_dob'] . '</b><br>'
          . 'URL : ' . $_SERVER['HTTP_REFERER'] . '<br>';

        // $cc_list = ["hr@kido.school"];
        $cc_list = [];
        $details = [
          "to" => "counsellor@amelio.in",
          "cc" => $cc_list,
          "receiver_name" => "Kido Corporate Solutions Team.",
          "subject" => "Kido Corporate Solutions Application.",
          "message" => $msg_html
        ];
        php_mailer($details);
        echo "Email Sent.";
        // print_r($_SERVER['HTTP_REFERER']);
        // die;

      }

    }

  }




}


?>